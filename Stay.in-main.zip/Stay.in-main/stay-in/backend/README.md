Postman Screenshots of backend APIs

localhost:8080/stay/1753434

<img width="1440" alt="Screenshot 2022-04-20 at 10 38 42 PM" src="https://user-images.githubusercontent.com/94420864/164363399-306ddf98-f3a1-42fd-b578-d17d10f0ee2e.png">

localhost:8080/createStay

<img width="1438" alt="Screenshot 2022-04-20 at 10 39 43 PM" src="https://user-images.githubusercontent.com/94420864/164363501-775e6f56-cd3e-4e06-8543-0d3c5ef75e89.png">

localhost:8080/updateStay/

<img width="1440" alt="Screenshot 2022-04-20 at 10 40 51 PM" src="https://user-images.githubusercontent.com/94420864/164363585-beb3cf51-3c71-49bd-a91e-def0d60cc67d.png">

localhost:8080/deleteStay/328

<img width="1440" alt="Screenshot 2022-04-20 at 10 41 23 PM" src="https://user-images.githubusercontent.com/94420864/164363644-eb11e6b8-25d4-4faa-9d72-d0a7deb4ba4a.png">

localhost:8080/schedule/11

<img width="1440" alt="Screenshot 2022-04-20 at 10 42 28 PM" src="https://user-images.githubusercontent.com/94420864/164363676-8bcf5124-be8c-450f-bb63-ffbd5f0e312d.png">

localhost:8080/createSchedule

<img width="1440" alt="Screenshot 2022-04-20 at 10 43 47 PM" src="https://user-images.githubusercontent.com/94420864/164363690-1eacc814-3866-4322-a641-77bba924d56d.png">

localhost:8080/updateSchedule/

<img width="1440" alt="Screenshot 2022-04-20 at 10 44 43 PM" src="https://user-images.githubusercontent.com/94420864/164363718-b9903cb2-24ed-4193-86b9-534d85f9ebfb.png">

localhost:8080/deleteSchedule/47

<img width="1439" alt="Screenshot 2022-04-20 at 10 45 11 PM" src="https://user-images.githubusercontent.com/94420864/164363753-1f1339e8-1904-48a3-8d9e-fc14c0e6361a.png">



